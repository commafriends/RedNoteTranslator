package com.example.rednotetranslator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val requestCapture = 1001
    private val requestOverlay = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 40)
        }
        val title = TextView(this).apply {
            text = "RedNote Translator"
            textSize = 25f
        }
        val desc = TextView(this).apply {
            text = "샤오홍슈 화면의 중국어 자막을 인식해 한국어로 번역합니다.\n\n" +
                "• 화면 텍스트 OCR 번역\n" +
                "• 번역 결과를 다른 앱 위에 표시\n" +
                "• 번역은 기기 내 ML Kit 모델 사용\n\n" +
                "주의: 이 버전은 화면에 보이는 글자를 번역합니다. " +
                "영상 음성 자체의 실시간 통역은 포함하지 않습니다."
            textSize = 16f
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "실시간 번역 시작"
            setOnClickListener { beginCaptureFlow() }
        }
        val stop = Button(this).apply {
            text = "번역 중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
            }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun beginCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, requestOverlay)
            return
        }
        requestScreenCapture()
    }

    @Deprecated("Legacy result API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) {
            requestScreenCapture()
        } else if (requestCode == requestCapture && resultCode == Activity.RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
            else startService(service)
            moveTaskToBack(true)
        }
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }
}
