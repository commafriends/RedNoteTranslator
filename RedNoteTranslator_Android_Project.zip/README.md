# RedNote Translator (Android prototype)

## What this prototype does
- Captures the visible Android screen after explicit MediaProjection consent.
- Runs Chinese-script OCR with Google ML Kit.
- Translates recognized text from Chinese to Korean using the on-device ML Kit translation model.
- Displays translated text in a bottom overlay above other apps.

## Important limitations
- This prototype translates **visible text only**. It does not listen to or transcribe video audio.
- OCR is performed on the captured screen at a prototype level; text may include buttons, comments, or unrelated UI, not only subtitles.
- Translation model download may require internet on first use.
- Android may block capture of secure/protected app surfaces.
- Screen capture requires the user's explicit system permission each session.
- Overlay permission must be granted in Android Settings.
- The app is a starter project and has not been compiled or device-tested in this environment.

## Build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync and install missing Android SDK 35 components if prompted.
3. Connect an Android device with USB debugging enabled.
4. Run the `app` configuration.
5. Open RedNote Translator, grant "Display over other apps", tap "실시간 번역 시작", and approve Android's screen-capture prompt.
6. Switch to Xiaohongshu. A translation strip should appear near the bottom.

## Stop
Return to the app and tap "번역 중지", or stop the foreground service from Android's app controls.

## Privacy
The prototype processes screen pixels locally and uses ML Kit's on-device OCR/translation. It does not upload captured frames to a custom server. Android system screen-capture indicators and permissions apply.
